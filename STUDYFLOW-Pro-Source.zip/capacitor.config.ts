import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.studyflow.app',
  appName: 'STUDYFLOW',
  webDir: 'dist',
  bundledWebRuntime: false
};
export default config;